#!/bin/bash
# INSTALL DEPS
sudo apt install gcc
sudo apt install gcc-multilib
sudo apt install nasm
sudo apt install make
sudo apt install xterm
